#include<iostream>
using namespace std;

int main(){

   float num1 = 0.0;
   float num2 = 0.0;
   cout << "enter number1" << endl;
   cin >> num1;	
   cout << "enter number1" << endl;
   cin >> num2;	
   cout << ""<<endl;
   cout << " sum " << num1 + num2 << endl;
   cout << " product " << num1 * num2 << endl;
   cout << " difference " << num1 - num2 << endl;
   cout << " quotient " << num1 / num2 << endl;
   
	return 0;
}
