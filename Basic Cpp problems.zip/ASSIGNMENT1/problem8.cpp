#include<iostream>
using namespace std;

int main(){
	
	int num0=0,num1=1, num2=2, num3=3, num4=4, num5=5,num6=6, num7=7, num8=8, num9=9, num10=10;
	cout << "integer"<< "   " << "square " << "    " << " cube " << endl;
	cout << num0     << "          " << num0*num0 << "          " << num0*num0*num0 << endl;
	cout << num1     << "          " << num1*num1 << "          " << num1*num1*num1 << endl;
	cout << num2     << "          " << num2*num2 << "          " << num2*num2*num2 << endl;
	cout << num3     << "          " << num3*num3 << "          " << num3*num3*num3 << endl;
	cout << num4     << "          " << num4*num4 <<"          " << num4*num4*num4 << endl;
	cout << num5     << "          " << num5*num5 <<"          " << num5*num5*num5 << endl;
	cout << num6     << "          " << num6*num6 <<"          " << num6*num6*num6 << endl;
	cout << num7     << "          " << num7*num7 <<"          " << num7*num7*num7 << endl;
	cout << num8     << "          " << num8*num8 <<"          " << num8*num8*num8 << endl;
	cout << num9     << "          " << num9*num9 <<"          " << num9*num9*num9 << endl;
	cout << num10    << "          " << num10*num10 <<"        " << num10*num10*num10 << endl;
}
